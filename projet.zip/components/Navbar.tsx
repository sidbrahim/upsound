'use client'
import React from 'react'
import Link from 'next/link'
import { signOut, useSession } from 'next-auth/react'
import '../styles/navbar.css'
import Image from 'next/image'

const Navbar = () => {
    const { data: session }: any = useSession()
    return (
    <header>   
        <div>
            <nav className="bar">
                <div className="nav">
                    
                        <div className="nav-items">
                            <Link href="/">
                                <Image src="/logo.png" className="logo" width={0} height={0} alt="" />
                            </Link>
                       
                            <div className='search-bar'>
                                <Image src="/search.png" className="search-icon" alt="" width={0} height={0} />
                                <input type="text" placeholder="Que recherchez vous"></input>
                            </div>
                            
                                {!session ? (
                                    <>
                                    <div className="item">
                                        <Link href="/login">
                                        <Image src="" className ="sign-up" alt="" width={0} height={0}/> <button>Sign In</button>
                                        </Link>

                                        <Link href="/register">
                                            <Image className ="log" src="" alt="" width={0} height={0}/>  <button> Log in </button>
                                        </Link>
                                     </div>   
                                    </>
                                ) : (
                                    <>
                                    {session.user?.email}
                                    <li>
                                        <button className= "p-2 px-5 -mt-1 bg-blue-800 rounded-full" 
                                        onClick={() => signOut()}>Se déconnecter</button>
                                    </li>
                                    </>
                                )
                                }


                            
                        </div>    
                 </div>   
                
             </nav>   
        </div>
    </header>     
    )
}

export default Navbar