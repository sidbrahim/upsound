
import Image from "next/image";


export default function Home() {
  return (
    <main >
  
            <div className="content">
                <h1>What is UPSound ?</h1>
                <p className="columned-paragraph">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Totam ut voluptates veniam aut distinctio repellendus culpa repellat saepe assumenda eius suscipit incidunt tenetur velit similique neque in impedit reiciendis, exercitationem quasi! Accusamus fugit hic ea quae repudiandae, facere blanditiis minus a qui non deleniti rem sint optio mollitia ad sed debitis dicta placeat! Voluptas sunt rerum, provident consequatur quia amet id, sed voluptates quod laudantium alias iste inventore recusandae, incidunt nesciunt rem maxime. Animi dolor natus, placeat culpa id tempore fuga ipsa neque cum illum sunt, esse velit voluptas quod laboriosam iure? Aspernatur placeat aliquid quisquam eos distinctio, illum rem ad et reiciendis quia necessitatibus? Quia, ipsam non. Optio, quaerat beatae quam perferendis voluptates eaque, maxime modi quod fugiat, ratione qui temporibus! Error laboriosam illum pariatur inventore, quae maiores qui soluta nihil nisi facere odio consequatur autem eveniet enim a iusto repudiandae officiis quibusdam asperiores. Aperiam quisquam reprehenderit nobis accusantium molestiae et autem dicta asperiores alias maiores, excepturi necessitatibus id minima sunt cum libero! Doloremque eaque hic delectus quae quam rem odio assumenda atque voluptate enim temporibus voluptatum, deleniti fugit corporis explicabo sit! Omnis minus alias magnam quaerat, enim saepe atque excepturi cum repudiandae. Ab nobis corrupti magnam ipsam nostrum laboriosam? Culpa, officiis placeat temporibus inventore qui quod quae! Incidunt consectetur provident sapiente, exercitationem minus architecto, fugit et quo dolorem magnam libero. Doloremque, minus deserunt facere, neque tenetur ullam animi cum eveniet quisquam suscipit voluptas laudantium. Totam omnis, consequuntur amet, nemo velit magnam ex, nisi earum ipsum alias molestias reprehenderit.</p>
           
            </div>
            <section className="musique-carte">
       
        <div className="card-container">
            <div className="card">
                <Image fill={true} src="/kendrick-lamar.png" alt="Nom de l'artiste" />
                <div className="information-card">
                    <h2>Kendrick Lamar</h2>
                    <h3>Humble</h3>
                    <button className="voir-button">
                        <span>See</span>
                        <Image src="/icons8-eye-30.png" alt="" width={20} height={20} /> 
                    </button>
                    <button className="like-button">
                        <span>Like</span>
                        <Image src="/icons8-like-30.png" alt="" width={20} height={20} /> 
                    </button>
                </div> 
            </div>
            <div className="card">
                <Image fill={true} src="/mb.png" alt="Nom de l'artiste" />
                <div className="information-card">
                    <h2>Metro Boomin</h2>
                    <h3>Humble</h3>
                    <button className="voir-button">
                        <span>See</span>
                        <Image src="/icons8-eye-30.png" alt="" width={20} height={20} /> 
                    </button>
                    <button className="like-button">
                        <span>Like</span>
                        <Image src="/icons8-like-30.png" alt="" width={20} height={20} /> 
                    </button>
                </div> 
            </div>
            <div className="card">
                <Image fill={true} src="/riles.jpg" alt="Nom de l'artiste" />
                <div className="information-card">
                    <h2>Riles</h2>
                    <h3>Queen</h3>
                    <button className="voir-button">
                        <span>See</span>
                        <Image src="/icons8-eye-30.png" alt="" width={20} height={20} /> 
                    </button>
                    <button className="like-button">
                        <span>Like</span>
                        <Image src="/icons8-like-30.png" alt="" width={20} height={20} /> 
                    </button>
                </div> 
            </div>
            <div className="card">
                <Image fill={true} src="/mb.png" alt="Nom de l'artiste"/>
                <div className="information-card">
                    <h2>Metro Boomin</h2>
                    <h3>Humble</h3>
                    <button className="voir-button">
                        <span>See</span>
                        <Image src="/icons8-eye-30.png" alt="" width={20} height={20} /> 
                    </button>
                    <button className="like-button">
                        <span>Like</span>
                        <Image src="/icons8-like-30.png" alt="" width={20} height={20}/> 
                    </button>
                </div>
            </div>
            
            
        
        </div>
    </section>
    </main>
  );
}
